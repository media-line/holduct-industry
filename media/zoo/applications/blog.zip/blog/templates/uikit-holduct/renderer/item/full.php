<?php
/**
 * @package   com_zoo
 * @author    YOOtheme http://www.yootheme.com
 * @copyright Copyright (C) YOOtheme GmbH
 * @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

//Проверка изображения
if ($this->checkPosition('media')){

	preg_match('/<img[^>]+>/i', $this->renderPosition('media'), $img);
	preg_match("/\<img.+src\=(?:\"|\')(.+?)(?:\"|\')(?:.+?)\>/", $img[0], $matches);

	$href = $matches[1];

} else {
	$href = '#';
}
?>

<?php if ($this->checkPosition('media')) : ?>
<a class="uk-article-full-image uk-align-left" href="<?php echo $href; ?>" data-uk-lightbox>
	<?php echo $this->renderPosition('media'); ?>
</a>
<?php endif; ?>

<?php if ($this->checkPosition('title')) : ?>
	<div class="uk-article-title">
		<?php echo $this->renderPosition('title'); ?>
	</div>
<?php endif; ?>

<?php if ($this->checkPosition('content')) : ?>
	<?php echo $this->renderPosition('content'); ?>
<?php endif; ?>
11
<?php// if ($this->checkPosition('related')) : ?>
	asd
	<h3><?php echo JText::_('Related Articles'); ?></h3>
	<?php echo $this->renderPosition('related'); ?>
<?php// endif; ?>
